import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otc',
  templateUrl: './otc.component.html',
  styleUrls: ['./otc.component.scss']
})
export class OtcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
