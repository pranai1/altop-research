import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { JoinComponent } from './join/join.component';
import { MarketComponent } from './market/market.component';
import { OtcComponent } from './otc/otc.component';
import { TeamComponent } from './team/team.component';
import { VenturesComponent } from './ventures/ventures.component';


const routes: Routes = [
  { path: '', redirectTo: 'about', pathMatch: 'full' },
  { path: 'about', component: AboutComponent },
  { path: 'team', component: TeamComponent },
  { path: 'otc', component: OtcComponent },
  { path: 'market-making', component: MarketComponent },
  { path: 'ventures', component: VenturesComponent },
  { path: 'join-us', component: JoinComponent },
  
  { path: 'contact-us', component: ContactUsComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
