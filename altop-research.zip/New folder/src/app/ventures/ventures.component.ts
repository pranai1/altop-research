import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ventures',
  templateUrl: './ventures.component.html',
  styleUrls: ['./ventures.component.scss']
})
export class VenturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
