import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { TeamComponent } from './team/team.component';
import { OtcComponent } from './otc/otc.component';
import { MarketComponent } from './market/market.component';
import { VenturesComponent } from './ventures/ventures.component';
import { JoinComponent } from './join/join.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    TeamComponent,
    OtcComponent,
    MarketComponent,
    VenturesComponent,
    JoinComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
